public class Main {

public static void main(String[] args) {
        Indexador indexador = new Indexador();
       indexador.indexaArquivosDoDiretorio();
   
        

   
   

}
	
}
